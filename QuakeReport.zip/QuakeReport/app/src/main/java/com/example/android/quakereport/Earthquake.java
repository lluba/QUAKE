package com.example.android.quakereport;

/**
 * Created by Joanna on 26.02.2018.
 */

public class Earthquake {

    /**Magnitude of the Earthquake */
    private String mMagnitude;

    /**Location of the Earthquake */
    private String mLocation;

    /**Dateof the Earthquake */
    private String mTime;



public Earthquake(String magnitude, String location, String time) {
    mMagnitude = magnitude;
    mLocation = location;
    mTime = time;
}

public String getMagnitude() {return mMagnitude;}

public String getLocation() {return mLocation;}

public String getTime() {return mTime;}

}